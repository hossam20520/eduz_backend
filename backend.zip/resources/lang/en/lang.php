<?php
   return [
      'Home' => 'Home'
   ];
?>
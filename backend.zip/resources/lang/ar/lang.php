<?php
   return [
      'Home' => 'Home.'
   ];
?>